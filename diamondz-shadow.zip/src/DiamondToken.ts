import { ethers } from "ethers"
import * as db from "./database"

interface FutureTransaction {
  address: string
  amount: bigint
  viewCount: number
  timestamp: number
}

export class DiamondzShadowMovies {
  private deployer: string
  public readonly name: string = "DiamondzShadowMovies"
  public readonly symbol: string = "DaSM"
  private lastOracleUpdate: number
  private currentPrice: number // Price in USD

  constructor() {
    this.deployer = process.env.DEPLOYER_ADDRESS || ethers.constants.AddressZero
    this.lastOracleUpdate = Date.now()
    this.currentPrice = this.getRandomPrice()
    this.initializeDatabase()
  }

  private async initializeDatabase() {
    await db.query(`
      CREATE TABLE IF NOT EXISTS balances (
        address TEXT PRIMARY KEY,
        balance NUMERIC(78, 0) NOT NULL
      )
    `)
    await db.query(`
      CREATE TABLE IF NOT EXISTS future_transactions (
        id SERIAL PRIMARY KEY,
        address TEXT NOT NULL,
        amount NUMERIC(78, 0) NOT NULL,
        view_count INTEGER NOT NULL,
        timestamp BIGINT NOT NULL
      )
    `)
    // Initialize deployer balance if not exists
    await db.query(
      `
      INSERT INTO balances (address, balance)
      VALUES ($1, $2)
      ON CONFLICT (address) DO NOTHING
    `,
      [this.deployer, (BigInt(1000000000) * BigInt(10) ** BigInt(18)).toString()],
    )
  }

  private getRandomPrice(): number {
    return 1 / (Math.random() * (15 - 5) + 5)
  }

  async updateOracle(): Promise<void> {
    const now = Date.now()
    if (now - this.lastOracleUpdate >= 3600000) {
      this.currentPrice = this.getRandomPrice()
      this.lastOracleUpdate = now
      console.log(`Oracle updated. New price: $${this.currentPrice.toFixed(4)}`)
    }
  }

  getCurrentPrice(): number {
    return this.currentPrice
  }

  async balanceOf(address: string): Promise<bigint> {
    const result = await db.query("SELECT balance FROM balances WHERE address = $1", [address])
    return result.rows[0] ? BigInt(result.rows[0].balance) : BigInt(0)
  }

  async transfer(from: string, to: string, amount: bigint): Promise<boolean> {
    const client = await db.getClient()
    try {
      await client.query("BEGIN")
      const fromBalance = await this.balanceOf(from)
      if (fromBalance < amount) {
        await client.query("ROLLBACK")
        return false
      }
      await client.query("UPDATE balances SET balance = balance - $1 WHERE address = $2", [amount.toString(), from])
      await client.query(
        "INSERT INTO balances (address, balance) VALUES ($1, $2) ON CONFLICT (address) DO UPDATE SET balance = balances.balance + $2",
        [to, amount.toString()],
      )
      await client.query("COMMIT")
      return true
    } catch (e) {
      await client.query("ROLLBACK")
      throw e
    } finally {
      client.release()
    }
  }

  async mint(to: string, amount: bigint): Promise<void> {
    if (to !== this.deployer) {
      throw new Error("Only the deployer can mint new DiamondzShadowMovies")
    }
    await db.query(
      "INSERT INTO balances (address, balance) VALUES ($1, $2) ON CONFLICT (address) DO UPDATE SET balance = balances.balance + $2",
      [to, amount.toString()],
    )
  }

  async burn(from: string, amount: bigint): Promise<boolean> {
    const client = await db.getClient()
    try {
      await client.query("BEGIN")
      const fromBalance = await this.balanceOf(from)
      if (fromBalance < amount) {
        await client.query("ROLLBACK")
        return false
      }
      await client.query("UPDATE balances SET balance = balance - $1 WHERE address = $2", [amount.toString(), from])
      await client.query("COMMIT")
      return true
    } catch (e) {
      await client.query("ROLLBACK")
      throw e
    } finally {
      client.release()
    }
  }

  async getTotalSupply(): Promise<bigint> {
    const result = await db.query("SELECT SUM(balance) as total_supply FROM balances")
    return BigInt(result.rows[0].total_supply || 0)
  }

  getDeployer(): string {
    return this.deployer
  }

  calculateReward(views: number): bigint {
    const rewardInUSD = views * 0.001 // $0.001 per view
    const rewardInDaSM = Math.floor(rewardInUSD / this.currentPrice)
    return BigInt(rewardInDaSM)
  }

  async recordFutureTransaction(address: string, views: number): Promise<void> {
    const reward = this.calculateReward(views)
    await db.query("INSERT INTO future_transactions (address, amount, view_count, timestamp) VALUES ($1, $2, $3, $4)", [
      address,
      reward.toString(),
      views,
      Date.now(),
    ])
  }

  async getFutureTransactions(): Promise<FutureTransaction[]> {
    const result = await db.query("SELECT * FROM future_transactions")
    return result.rows.map((row) => ({
      address: row.address,
      amount: BigInt(row.amount),
      viewCount: row.view_count,
      timestamp: row.timestamp,
    }))
  }

  async processFutureTransactions(): Promise<void> {
    const now = Date.now()
    const client = await db.getClient()
    try {
      await client.query("BEGIN")
      const result = await client.query("SELECT * FROM future_transactions WHERE timestamp <= $1", [
        now - 24 * 60 * 60 * 1000,
      ])
      for (const tx of result.rows) {
        await this.mint(this.deployer, BigInt(tx.amount))
        await this.transfer(this.deployer, tx.address, BigInt(tx.amount))
      }
      await client.query("DELETE FROM future_transactions WHERE timestamp <= $1", [now - 24 * 60 * 60 * 1000])
      await client.query("COMMIT")
    } catch (e) {
      await client.query("ROLLBACK")
      throw e
    } finally {
      client.release()
    }
  }
}

export const diamondzShadowMovies = new DiamondzShadowMovies()

