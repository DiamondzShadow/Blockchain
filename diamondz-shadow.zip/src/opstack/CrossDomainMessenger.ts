import { ethers } from "ethers"
import { L2_CONFIG } from "../../config/l2-config"

export class CrossDomainMessenger {
  private l1Messenger: ethers.Contract
  private l2Messenger: ethers.Contract

  constructor(
    private l1Provider: ethers.providers.JsonRpcProvider,
    private l2Provider: ethers.providers.JsonRpcProvider,
    private l1MessengerAddress: string,
  ) {
    const l1MessengerAbi = ["function sendMessage(address _target, bytes memory _message, uint32 _gasLimit) external"]
    this.l1Messenger = new ethers.Contract(l1MessengerAddress, l1MessengerAbi, l1Provider)

    const l2MessengerAbi = ["function sendMessage(address _target, bytes memory _message, uint32 _gasLimit) external"]
    this.l2Messenger = new ethers.Contract(L2_CONFIG.L2_CROSS_DOMAIN_MESSENGER_ADDRESS, l2MessengerAbi, l2Provider)
  }

  async initialize(): Promise<void> {
    console.log("Initializing Cross Domain Messenger...")
    // Perform any necessary initialization for the cross-domain messenger
    // For example, you might want to check if the contracts are deployed and accessible
    const l1Code = await this.l1Provider.getCode(this.l1MessengerAddress)
    const l2Code = await this.l2Provider.getCode(L2_CONFIG.L2_CROSS_DOMAIN_MESSENGER_ADDRESS)

    if (l1Code === "0x" || l2Code === "0x") {
      throw new Error("Cross Domain Messenger contracts not deployed")
    }

    console.log("Cross Domain Messenger initialized successfully")
  }

  async sendL1ToL2Message(target: string, message: string, gasLimit: number): Promise<void> {
    console.log(`Sending message from L1 to L2: ${message}`)
    await this.l1Messenger.sendMessage(target, ethers.utils.defaultAbiCoder.encode(["string"], [message]), gasLimit)
  }

  async sendL2ToL1Message(target: string, message: string, gasLimit: number): Promise<void> {
    console.log(`Sending message from L2 to L1: ${message}`)
    await this.l2Messenger.sendMessage(target, ethers.utils.defaultAbiCoder.encode(["string"], [message]), gasLimit)
  }
}

