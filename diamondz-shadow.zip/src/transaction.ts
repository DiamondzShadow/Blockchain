export class Transaction {
  constructor(
    public from: string,
    public to: string,
    public amount: bigint,
    public gasPrice: bigint,
    public gasLimit: number,
    public data: string,
  ) {}
}

