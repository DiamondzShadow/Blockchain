import { ethers } from "ethers"
import { CrossChainMessenger, MessageStatus } from "@eth-optimism/sdk"

export class L2Node {
  private crossChainMessenger: CrossChainMessenger

  constructor(
    private l1Provider: ethers.providers.JsonRpcProvider,
    private l2Provider: ethers.providers.JsonRpcProvider,
    private config: any,
  ) {}

  async initialize(): Promise<void> {
    this.crossChainMessenger = new CrossChainMessenger({
      l1SignerOrProvider: this.l1Provider,
      l2SignerOrProvider: this.l2Provider,
      l1ChainId: this.config.L1_CHAIN_ID,
      l2ChainId: this.config.L2_CHAIN_ID,
    })
  }

  async start(): Promise<void> {
    // Start processing L1 to L2 messages
    this.processL1ToL2Messages()

    // Start monitoring L2 transactions
    this.monitorL2Transactions()
  }

  private async processL1ToL2Messages(): Promise<void> {
    console.log("Starting to process L1 to L2 messages")
    while (true) {
      try {
        const messages = await this.crossChainMessenger.getMessagesByStatus(MessageStatus.READY_TO_PROVE)
        for (const message of messages) {
          await this.crossChainMessenger.proveMessage(message)
          console.log(`Proved message: ${message.transactionHash}`)
        }
      } catch (error) {
        console.error("Error processing L1 to L2 messages:", error)
      }
      await new Promise((resolve) => setTimeout(resolve, 15000)) // Wait for 15 seconds before next iteration
    }
  }

  private async monitorL2Transactions(): Promise<void> {
    console.log("Starting to monitor L2 transactions")
    this.l2Provider.on("block", async (blockNumber) => {
      try {
        const block = await this.l2Provider.getBlock(blockNumber)
        console.log(`New L2 block: ${blockNumber}, Transactions: ${block.transactions.length}`)

        for (const txHash of block.transactions) {
          const tx = await this.l2Provider.getTransaction(txHash)
          console.log(
            `Transaction: ${txHash}, From: ${tx.from}, To: ${tx.to}, Value: ${ethers.utils.formatEther(tx.value)} ETH`,
          )
        }
      } catch (error) {
        console.error("Error monitoring L2 transactions:", error)
      }
    })
  }
}

