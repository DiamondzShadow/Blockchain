import { google, type youtube_v3 } from "googleapis"
import type { Block } from "./block"

export class ProofOfContributionConsensus {
  private youtube: youtube_v3.Youtube
  private contributionScores: Map<string, number>
  private channelId = "UCFpbJ3ifENP8shXOfQHyv9g"

  constructor() {
    this.youtube = google.youtube({
      version: "v3",
      auth: process.env.YOUTUBE_API_KEY,
    })
    this.contributionScores = new Map()
  }

  async validateBlock(block: Block): Promise<boolean> {
    console.log(`Validating block ${block.index}`)

    // Validate the miner's contribution
    const isValidContribution = await this.validateContribution(block.miner, block.contribution)

    if (!isValidContribution) {
      console.log(`Invalid contribution for block ${block.index}`)
      return false
    }

    // Update the miner's contribution score
    this.updateContributionScore(block.miner)

    return true
  }

  async validateContribution(address: string, contribution: string): Promise<boolean> {
    // Extract YouTube video ID from the contribution string
    const videoId = this.extractVideoId(contribution)

    if (!videoId) {
      console.log(`Invalid YouTube video ID in contribution`)
      return false
    }

    try {
      const response = await this.youtube.videos.list({
        part: ["snippet", "statistics", "contentDetails"],
        id: [videoId],
      })

      if (response.data.items && response.data.items.length > 0) {
        const video = response.data.items[0]
        const videoChannelId = video.snippet?.channelId

        if (videoChannelId !== this.channelId) {
          console.log(`Video does not belong to the specified channel`)
          return false
        }

        const viewCount = Number.parseInt(video.statistics?.viewCount || "0", 10)
        const likeCount = Number.parseInt(video.statistics?.likeCount || "0", 10)
        const commentCount = Number.parseInt(video.statistics?.commentCount || "0", 10)
        const duration = video.contentDetails?.duration || ""

        // Enhanced criteria for a valid contribution
        if (viewCount >= 1000 && likeCount >= 50 && commentCount >= 10 && this.isValidDuration(duration)) {
          return true
        }
      }
    } catch (error) {
      console.error("Error validating YouTube contribution:", error)
    }

    return false
  }

  private extractVideoId(contribution: string): string | null {
    const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(.+)/
    const match = contribution.match(regex)
    return match ? match[1] : null
  }

  private isValidDuration(duration: string): boolean {
    // Parse ISO 8601 duration
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/)
    if (!match) return false

    const hours = Number.parseInt(match[1] || "0", 10)
    const minutes = Number.parseInt(match[2] || "0", 10)
    const seconds = Number.parseInt(match[3] || "0", 10)

    const totalSeconds = hours * 3600 + minutes * 60 + seconds

    // Require videos to be between 5 minutes and 2 hours
    return totalSeconds >= 300 && totalSeconds <= 7200
  }

  private updateContributionScore(address: string): void {
    const currentScore = this.contributionScores.get(address) || 0
    this.contributionScores.set(address, currentScore + 1)
  }

  async selectMiner(activeAddresses: string[]): Promise<string> {
    // Select miner based on contribution scores
    let totalScore = 0
    const scores = activeAddresses.map((address) => {
      const score = this.contributionScores.get(address) || 0
      totalScore += score
      return { address, score }
    })

    if (totalScore === 0) {
      // If no contributions yet, select randomly
      return activeAddresses[Math.floor(Math.random() * activeAddresses.length)]
    }

    const random = Math.random() * totalScore
    let cumulativeScore = 0
    for (const { address, score } of scores) {
      cumulativeScore += score
      if (random <= cumulativeScore) {
        return address
      }
    }

    // Fallback to the last address (should never happen)
    return activeAddresses[activeAddresses.length - 1]
  }

  getTopContributors(limit: number): { address: string; score: number }[] {
    return Array.from(this.contributionScores.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([address, score]) => ({ address, score }))
  }
}

