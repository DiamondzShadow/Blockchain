import { ethers } from "ethers"
import type { Transaction } from "./transaction"

export class Block {
  public hash: string

  constructor(
    public index: number,
    public timestamp: number,
    public transactions: Transaction[],
    public previousHash: string,
    public miner: string,
    public contribution: string,
  ) {
    this.hash = this.calculateHash()
  }

  calculateHash(): string {
    return ethers.utils.id(
      this.index +
        this.timestamp +
        JSON.stringify(this.transactions) +
        this.previousHash +
        this.miner +
        this.contribution,
    )
  }
}

