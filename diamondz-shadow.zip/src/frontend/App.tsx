"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { ethers } from "ethers"

interface Block {
  index: number
  timestamp: number
  transactions: Transaction[]
  previousHash: string
  hash: string
  miner: string
  contribution: string
}

interface Transaction {
  from: string
  to: string
  amount: string
  contribution: string
  hash: string
}

interface Contributor {
  address: string
  score: number
}

const App: React.FC = () => {
  const [blocks, setBlocks] = useState<Block[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [topContributors, setTopContributors] = useState<Contributor[]>([])
  const [newTransaction, setNewTransaction] = useState({
    from: "",
    to: "",
    amount: "",
    contribution: "",
    privateKey: "",
  })

  useEffect(() => {
    fetchChainData()
    fetchTopContributors()
  }, [])

  const fetchChainData = async () => {
    const response = await fetch("http://localhost:3000/chain")
    const chainData = await response.json()
    setBlocks(chainData)
    const allTransactions = chainData.flatMap((block: Block) => block.transactions)
    setTransactions(allTransactions)
  }

  const fetchTopContributors = async () => {
    const response = await fetch("http://localhost:3000/top-contributors")
    const contributors = await response.json()
    setTopContributors(contributors)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewTransaction({ ...newTransaction, [e.target.name]: e.target.value })
  }

  const handleSubmitTransaction = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("http://localhost:3000/transaction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTransaction),
      })
      const result = await response.json()
      alert(`Transaction submitted: ${result.hash}`)
      setNewTransaction({ from: "", to: "", amount: "", contribution: "", privateKey: "" })
      fetchChainData()
    } catch (error) {
      alert(`Error submitting transaction: ${error.message}`)
    }
  }

  const handleMineBlock = async () => {
    try {
      const response = await fetch("http://localhost:3000/mine", { method: "POST" })
      const result = await response.json()
      alert(`New block mined: ${result.block.hash}`)
      fetchChainData()
      fetchTopContributors()
    } catch (error) {
      alert(`Error mining block: ${error.message}`)
    }
  }

  return (
    <div>
      <h1>Diamondz Shadow Blockchain</h1>

      <h2>Submit Transaction</h2>
      <form onSubmit={handleSubmitTransaction}>
        <input name="from" value={newTransaction.from} onChange={handleInputChange} placeholder="From" required />
        <input name="to" value={newTransaction.to} onChange={handleInputChange} placeholder="To" required />
        <input
          name="amount"
          value={newTransaction.amount}
          onChange={handleInputChange}
          placeholder="Amount"
          required
          type="number"
          step="0.000000000000000001"
        />
        <input
          name="contribution"
          value={newTransaction.contribution}
          onChange={handleInputChange}
          placeholder="Contribution"
          required
        />
        <input
          name="privateKey"
          value={newTransaction.privateKey}
          onChange={handleInputChange}
          placeholder="Private Key"
          required
          type="password"
        />
        <button type="submit">Submit Transaction</button>
      </form>

      <h2>Mine Block</h2>
      <button onClick={handleMineBlock}>Mine New Block</button>

      <h2>Top Contributors</h2>
      <ul>
        {topContributors.map((contributor, index) => (
          <li key={index}>
            {contributor.address}: {contributor.score}
          </li>
        ))}
      </ul>

      <h2>Recent Transactions</h2>
      <ul>
        {transactions.slice(-5).map((tx, index) => (
          <li key={index}>
            From: {tx.from}, To: {tx.to}, Amount: {ethers.utils.formatEther(tx.amount)}, Contribution: {tx.contribution}
          </li>
        ))}
      </ul>

      <h2>Blockchain</h2>
      <ul>
        {blocks.map((block) => (
          <li key={block.index}>
            Block {block.index}: {block.hash} (Mined by: {block.miner})
          </li>
        ))}
      </ul>
    </div>
  )
}

export default App

