import { DiamondsShadowChain } from "./chain"
import { ProofOfContributionConsensus } from "./consensus"
import { API } from "./api"
import { L2_CONFIG } from "../config/l2-config"
import { Network, Alchemy } from "alchemy-sdk"
import { L2Node } from "./l2/L2Node"
import { ethers } from "ethers"

async function main() {
  const l1RpcUrl = process.env.L1_RPC_URL || "https://mainnet.infura.io/v3/YOUR-PROJECT-ID"
  const l2RpcUrl = L2_CONFIG.L2_RPC_URL
  const consensus = new ProofOfContributionConsensus()
  const chain = new DiamondsShadowChain(consensus, l1RpcUrl, l2RpcUrl)
  const api = new API(chain)

  // Alchemy SDK setup
  const alchemySettings = {
    apiKey: process.env.ALCHEMY_API_KEY,
    network: Network.ETH_MAINNET,
  }
  const alchemy = new Alchemy(alchemySettings)

  // L2 Node setup
  const l1Provider = new ethers.providers.JsonRpcProvider(l1RpcUrl)
  const l2Provider = new ethers.providers.JsonRpcProvider(l2RpcUrl)
  const l2Node = new L2Node(l1Provider, l2Provider, L2_CONFIG)

  try {
    await chain.initialize()
    console.log("Diamondz Shadow blockchain initialized successfully")

    await l2Node.initialize()
    console.log("L2 Node initialized successfully")

    const blockNumber = await alchemy.core.getBlockNumber("finalized")
    console.log("Latest finalized Ethereum block number:", blockNumber)

    const l2BlockNumber = await l2Provider.getBlockNumber()
    console.log("Latest Optimism block number:", l2BlockNumber)

    const port = process.env.PORT || 3000
    api.start(port)
    console.log(`Diamondz Shadow API is running on port ${port}`)

    // Start L2 Node processes
    await l2Node.start()
    console.log("L2 Node started successfully")
  } catch (error) {
    console.error("Failed to start Diamondz Shadow L2 node:", error)
    process.exit(1)
  }
}

main().catch((error) => {
  console.error("Unhandled error:", error)
  process.exit(1)
})

