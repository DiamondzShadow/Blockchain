import { ethers } from "ethers"
import { Block } from "./block"
import type { Transaction } from "./transaction"
import type { ProofOfContributionConsensus } from "./consensus"
import { diamondzShadowMovies } from "./DiamondToken"
import { L2_CONFIG } from "../config/l2-config"

export class DiamondsShadowChain {
  private blocks: Block[]
  private pendingTransactions: Transaction[]
  private consensus: ProofOfContributionConsensus
  private l1Provider: ethers.providers.JsonRpcProvider
  private l2Provider: ethers.providers.JsonRpcProvider

  constructor(
    consensus: ProofOfContributionConsensus,
    private l1RpcUrl: string = L2_CONFIG.L1_RPC_URL,
    private l2RpcUrl: string = L2_CONFIG.L2_RPC_URL,
  ) {
    this.blocks = [this.createGenesisBlock()]
    this.pendingTransactions = []
    this.consensus = consensus

    // Initialize providers
    this.l1Provider = new ethers.providers.JsonRpcProvider(this.l1RpcUrl)
    this.l2Provider = new ethers.providers.JsonRpcProvider(this.l2RpcUrl)
  }

  private createGenesisBlock(): Block {
    return new Block(0, Date.now(), [], "Genesis Block")
  }

  async initialize(): Promise<void> {
    console.log("Initializing Diamondz Shadow blockchain...")
    console.log(`Connecting to L1: ${this.l1RpcUrl}`)
    console.log(`Initializing L2: ${this.l2RpcUrl}`)

    // Verify L1 connection
    try {
      const l1BlockNumber = await this.l1Provider.getBlockNumber()
      console.log(`Successfully connected to L1. Current block: ${l1BlockNumber}`)
    } catch (error) {
      console.error("Failed to connect to L1:", error)
      throw new Error("L1 connection failed")
    }
  }

  async addTransaction(transaction: Transaction): Promise<void> {
    // Verify the transaction has enough DiamondzShadowMovies for gas
    const senderBalance = await diamondzShadowMovies.balanceOf(transaction.from)
    if (senderBalance < transaction.gasPrice * BigInt(transaction.gasLimit)) {
      throw new Error("Insufficient DiamondzShadowMovies for gas")
    }

    this.pendingTransactions.push(transaction)
  }

  async mineBlock(): Promise<Block> {
    const previousBlock = this.getLatestBlock()
    const miner = await this.consensus.selectMiner(this.getActiveAddresses())
    const contribution = `Mined block ${previousBlock.index + 1}`

    const newBlock = new Block(
      previousBlock.index + 1,
      Date.now(),
      this.pendingTransactions,
      previousBlock.hash,
      miner,
      contribution,
    )

    const isValid = await this.consensus.validateBlock(newBlock)
    if (!isValid) {
      throw new Error("Block validation failed")
    }

    this.blocks.push(newBlock)

    // Reward the miner with DiamondzShadowMovies
    await diamondzShadowMovies.mint(miner, BigInt(1000) * BigInt(10) ** BigInt(18)) // 1000 DiamondzShadowMovies

    this.pendingTransactions = []

    return newBlock
  }

  getLatestBlock(): Block {
    return this.blocks[this.blocks.length - 1]
  }

  getChain(): Block[] {
    return this.blocks
  }

  async getBalance(address: string): Promise<bigint> {
    return diamondzShadowMovies.balanceOf(address)
  }

  async validateChain(): Promise<boolean> {
    for (let i = 1; i < this.blocks.length; i++) {
      const currentBlock = this.blocks[i]
      const previousBlock = this.blocks[i - 1]

      if (currentBlock.previousHash !== previousBlock.hash) {
        return false
      }

      if (currentBlock.hash !== currentBlock.calculateHash()) {
        return false
      }

      if (!(await this.consensus.validateBlock(currentBlock))) {
        return false
      }
    }
    return true
  }

  getActiveAddresses(): string[] {
    const addresses = new Set<string>()
    this.blocks.forEach((block) => {
      addresses.add(block.miner)
      block.transactions.forEach((tx) => {
        addresses.add(tx.from)
        addresses.add(tx.to)
      })
    })
    return Array.from(addresses)
  }

  getTopContributors(limit = 10): { address: string; score: number }[] {
    return this.consensus.getTopContributors(limit)
  }
}

