import express from "express"
import cors from "cors"
import { ethers } from "ethers"
import { Network, Alchemy } from "alchemy-sdk"
import type { DiamondsShadowChain } from "./chain"
import { Transaction } from "./transaction"

export class API {
  private app: express.Application
  private alchemy: Alchemy

  constructor(private chain: DiamondsShadowChain) {
    this.app = express()
    this.setupMiddleware()
    this.setupRoutes()

    // Initialize Alchemy
    const alchemySettings = {
      apiKey: process.env.ALCHEMY_API_KEY || "3g7LKkKWyUVcOndx1ZOUt6VLjFOhCPUg", // It's better to use an environment variable for the API key
      network: Network.ETH_MAINNET,
    }
    this.alchemy = new Alchemy(alchemySettings)
  }

  private setupMiddleware(): void {
    this.app.use(express.json())
    this.app.use(cors())
  }

  private setupRoutes(): void {
    this.app.get("/chain", (req, res) => {
      res.json(this.chain.getChain())
    })

    this.app.post("/transaction", async (req, res) => {
      try {
        const { from, to, amount, contribution, privateKey } = req.body
        const transaction = new Transaction(
          from,
          to,
          ethers.utils.parseEther(amount),
          contribution,
          (await this.chain.getLatestBlock().index) + 1,
        )
        const signature = transaction.sign(privateKey)
        if (!transaction.verifySignature(signature)) {
          throw new Error("Invalid signature")
        }
        await this.chain.addTransaction(transaction)
        res.json({ message: "Transaction added to pending transactions", hash: transaction.hash })
      } catch (error) {
        res.status(400).json({ error: error.message })
      }
    })

    this.app.post("/mine", async (req, res) => {
      try {
        const newBlock = await this.chain.mineBlock()
        res.json({ message: "New block mined", block: newBlock })
      } catch (error) {
        res.status(400).json({ error: error.message })
      }
    })

    this.app.get("/balance/:address", async (req, res) => {
      try {
        const balance = await this.chain.getBalance(req.params.address)
        res.json({ balance: ethers.utils.formatEther(balance) })
      } catch (error) {
        res.status(400).json({ error: error.message })
      }
    })

    this.app.get("/top-contributors", (req, res) => {
      const limit = Number.parseInt(req.query.limit as string) || 10
      const topContributors = this.chain.getTopContributors(limit)
      res.json(topContributors)
    })

    // New endpoint using Alchemy SDK
    this.app.get("/ethereum-block", async (req, res) => {
      try {
        const blockNumber = await this.alchemy.core.getBlockNumber("finalized")
        res.json({ latestFinalizedBlockNumber: blockNumber })
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch Ethereum block number" })
      }
    })
  }

  start(port: number): void {
    this.app.listen(port, () => {
      console.log(`Diamondz Shadow API is running on port ${port}`)
    })
  }
}

