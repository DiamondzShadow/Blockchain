import express from "express"
import { DiamondsShadowChain } from "./chain"
import { ProofOfContributionConsensus } from "./consensus"
import { diamondzShadowMovies } from "./DiamondToken"
import dotenv from "dotenv"

dotenv.config()

const app = express()
const port = process.env.PORT || 3000

app.use(express.json())

const consensus = new ProofOfContributionConsensus()
const chain = new DiamondsShadowChain(consensus)

app.get("/", (req, res) => {
  res.send("Welcome to Diamondz Shadow Blockchain!")
})

app.get("/chain", (req, res) => {
  res.json(chain.getChain())
})

app.post("/mine", async (req, res) => {
  try {
    const newBlock = await chain.mineBlock()
    res.json({ message: "New block mined", block: newBlock })
  } catch (error) {
    res.status(500).json({ error: "Error mining block" })
  }
})

app.get("/balance/:address", async (req, res) => {
  try {
    const balance = await chain.getBalance(req.params.address)
    res.json({ balance: balance.toString() })
  } catch (error) {
    res.status(500).json({ error: "Error fetching balance" })
  }
})

// DiamondzShadowMovies operations
app.get("/dasm/balance/:address", async (req, res) => {
  const balance = await diamondzShadowMovies.balanceOf(req.params.address)
  res.json({ balance: balance.toString() })
})

app.post("/dasm/transfer", async (req, res) => {
  const { from, to, amount } = req.body
  const success = await diamondzShadowMovies.transfer(from, to, BigInt(amount))
  if (success) {
    res.json({ message: "Transfer successful" })
  } else {
    res.status(400).json({ error: "Transfer failed" })
  }
})

app.post("/dasm/mint", async (req, res) => {
  const { amount } = req.body
  try {
    await diamondzShadowMovies.mint(diamondzShadowMovies.getDeployer(), BigInt(amount))
    res.json({ message: "DiamondzShadowMovies minted successfully" })
  } catch (error) {
    res.status(400).json({ error: "Minting failed" })
  }
})

app.post("/dasm/burn", async (req, res) => {
  const { from, amount } = req.body
  const success = await diamondzShadowMovies.burn(from, BigInt(amount))
  if (success) {
    res.json({ message: "DiamondzShadowMovies burned successfully" })
  } else {
    res.status(400).json({ error: "Burn failed" })
  }
})

app.get("/dasm/info", async (req, res) => {
  res.json({
    name: diamondzShadowMovies.name,
    symbol: diamondzShadowMovies.symbol,
    totalSupply: await diamondzShadowMovies.getTotalSupply(),
    deployer: diamondzShadowMovies.getDeployer(),
    currentPrice: diamondzShadowMovies.getCurrentPrice(),
  })
})

app.post("/contribute", async (req, res) => {
  try {
    const { address, videoUrl, views } = req.body
    const isValid = await consensus.validateContribution(address, videoUrl)
    if (isValid) {
      await diamondzShadowMovies.recordFutureTransaction(address, views)
      res.json({ message: "Contribution submitted successfully", status: "valid" })
    } else {
      res.status(400).json({
        error: "Invalid contribution",
        status: "invalid",
        reason: "Video does not meet the criteria or does not belong to the specified channel",
      })
    }
  } catch (error) {
    res.status(500).json({ error: "Error submitting contribution", status: "error" })
  }
})

app.get("/top-contributors", (req, res) => {
  const limit = Number(req.query.limit) || 10
  const topContributors = chain.getTopContributors(limit)
  res.json(topContributors)
})

app.get("/check-reward/:views", (req, res) => {
  const views = Number.parseInt(req.params.views, 10)
  if (isNaN(views)) {
    res.status(400).json({ error: "Invalid view count" })
    return
  }
  const reward = diamondzShadowMovies.calculateReward(views)
  const currentPrice = diamondzShadowMovies.getCurrentPrice()
  res.json({
    views,
    reward: reward.toString(),
    rewardInUSD: (Number(reward) * currentPrice).toFixed(2),
    currentPrice: currentPrice.toFixed(4),
  })
})

app.get("/dasm/price", (req, res) => {
  const price = diamondzShadowMovies.getCurrentPrice()
  res.json({ price: price.toFixed(4) })
})

app.post("/dasm/update-oracle", (req, res) => {
  diamondzShadowMovies.updateOracle()
  const newPrice = diamondzShadowMovies.getCurrentPrice()
  res.json({ message: "Oracle updated", newPrice: newPrice.toFixed(4) })
})

app.get("/dasm/future-transactions", async (req, res) => {
  const futureTransactions = await diamondzShadowMovies.getFutureTransactions()
  res.json(futureTransactions)
})

app.post("/dasm/process-future-transactions", async (req, res) => {
  await diamondzShadowMovies.processFutureTransactions()
  res.json({ message: "Future transactions processed" })
})

app.listen(port, () => {
  console.log(`Diamondz Shadow server running at http://localhost:${port}`)
})

// Initialize the chain
chain.initialize().catch(console.error)

