import { ethers } from "ethers"
import { L2_CONFIG } from "../config/l2-config"
import dotenv from "dotenv"

// Load environment variables
dotenv.config()

async function main() {
  console.log("Initializing Diamondz Shadow environment...")

  // Verify environment variables
  const requiredEnvVars = ["INFURA_PROJECT_ID", "PRIVATE_KEY", "SEQUENCER_PRIVATE_KEY", "BATCH_SUBMITTER_PRIVATE_KEY"]

  const missingVars = requiredEnvVars.filter((varName) => !process.env[varName])
  if (missingVars.length > 0) {
    console.error(`Missing required environment variables: ${missingVars.join(", ")}`)
    process.exit(1)
  }

  // Connect to L1
  const l1Provider = new ethers.providers.JsonRpcProvider(L2_CONFIG.L1_RPC_URL)
  const deployer = new ethers.Wallet(process.env.PRIVATE_KEY!, l1Provider)
  const sequencer = new ethers.Wallet(process.env.SEQUENCER_PRIVATE_KEY!, l1Provider)
  const batchSubmitter = new ethers.Wallet(process.env.BATCH_SUBMITTER_PRIVATE_KEY!, l1Provider)

  console.log(`Deployer address: ${deployer.address}`)
  console.log(`Sequencer address: ${sequencer.address}`)
  console.log(`Batch submitter address: ${batchSubmitter.address}`)

  // Check L1 balance
  const deployerBalance = await l1Provider.getBalance(deployer.address)
  console.log(`Deployer balance: ${ethers.utils.formatEther(deployerBalance)} ETH`)

  if (deployerBalance.lt(ethers.utils.parseEther("0.1"))) {
    console.warn("Warning: Deployer balance is low. You may need more ETH to deploy contracts.")
  }

  // Connect to L2 (if available)
  try {
    const l2Provider = new ethers.providers.JsonRpcProvider(L2_CONFIG.L2_RPC_URL)
    const l2BlockNumber = await l2Provider.getBlockNumber()
    console.log(`Successfully connected to L2. Current block: ${l2BlockNumber}`)
  } catch (error) {
    console.log("L2 node not yet available. This is expected if you haven't deployed your L2 yet.")
  }

  console.log("Environment initialization complete!")
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })

