import { ethers } from "ethers"
import { getContractFactory } from "@eth-optimism/contracts"
import dotenv from "dotenv"

dotenv.config()

async function main() {
  // Connect to L1 (Polygon Amoy)
  const l1RpcUrl = process.env.L1_RPC_URL
  const l1Provider = new ethers.providers.JsonRpcProvider(l1RpcUrl)
  const deployer = new ethers.Wallet(process.env.PRIVATE_KEY!, l1Provider)

  console.log("Deploying L1 contracts...")

  // Deploy L1CrossDomainMessenger
  const L1CrossDomainMessenger = getContractFactory("L1CrossDomainMessenger", deployer)
  const l1CrossDomainMessenger = await L1CrossDomainMessenger.deploy()
  await l1CrossDomainMessenger.deployed()
  console.log("L1CrossDomainMessenger deployed to:", l1CrossDomainMessenger.address)

  // Deploy CanonicalTransactionChain
  const CanonicalTransactionChain = getContractFactory("CanonicalTransactionChain", deployer)
  const canonicalTransactionChain = await CanonicalTransactionChain.deploy()
  await canonicalTransactionChain.deployed()
  console.log("CanonicalTransactionChain deployed to:", canonicalTransactionChain.address)

  // Deploy StateCommitmentChain
  const StateCommitmentChain = getContractFactory("StateCommitmentChain", deployer)
  const stateCommitmentChain = await StateCommitmentChain.deploy()
  await stateCommitmentChain.deployed()
  console.log("StateCommitmentChain deployed to:", stateCommitmentChain.address)

  // Deploy L1StandardBridge
  const L1StandardBridge = getContractFactory("L1StandardBridge", deployer)
  const l1StandardBridge = await L1StandardBridge.deploy()
  await l1StandardBridge.deployed()
  console.log("L1StandardBridge deployed to:", l1StandardBridge.address)

  console.log("L1 contracts deployed successfully!")
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })

