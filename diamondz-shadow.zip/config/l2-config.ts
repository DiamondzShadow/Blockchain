export const L2_CONFIG = {
  // L1 configuration
  L1_RPC_URL: process.env.L1_RPC_URL || "https://polygon-amoy.infura.io/v3/36db7db7f76140d680587b5e3535771d",
  L1_CHAIN_ID: 80001, // Polygon Amoy testnet

  // L2 configuration
  L2_RPC_URL: process.env.ALCHEMY_API_KEY
    ? `https://polygon-amoy.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`
    : "http://localhost:8545",
  L2_CHAIN_ID: 42069, // Custom chain ID for Diamondz Shadow

  // Contract addresses (to be filled after deployment)
  L1_CROSS_DOMAIN_MESSENGER_ADDRESS: "0x...",
  L2_CROSS_DOMAIN_MESSENGER_ADDRESS: "0x4200000000000000000000000000000000000007",
  L1_STANDARD_BRIDGE_ADDRESS: "0x...",
  L2_STANDARD_BRIDGE_ADDRESS: "0x4200000000000000000000000000000000000010",

  // Sequencer configuration
  SEQUENCER_ADDRESS: "0x...", // Will be derived from SEQUENCER_PRIVATE_KEY

  // Batch submitter configuration
  BATCH_SUBMITTER_ADDRESS: "0x...", // Will be derived from BATCH_SUBMITTER_PRIVATE_KEY

  // Server configuration
  PORT: process.env.PORT || 3000,
}

